from cgitb import text
from multiprocessing import context

from behave import *
from selenium import webdriver


@given('I lunch chrome browser')
def lunch_Chromebrowser(context):
    context.driver=webdriver.Chrome(executable_path="C:\Drivers\Chrome\chromedriver.exe")


@when('I open OrengeHRM Homepage')
def open_Orangehrmhomepage(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")

@when(u'Enter Username "{user}" and password "{PWD}"')
def EnteruserNAndpwd(context,user,PWD):
    context.driver.find_element_by_id("txtUsername").send_keys("Admin")
    context.driver.find_element_by_id("txtPassword").send_keys("admin123")


@when('Click login button')
def login(context):
    context.driver.find_element_by_id("btnLogin").click()


@then('User must login successfully to the Dashboard')
def step_impl(context):
    try:
       text=context.driver.find_element_by_xpath("//h1[normalize-space()='Dashboard']").text
    except:
        context.driver.close()
        assert False, "Test Failed"
    if text =="Dashboard":
       context.driver.close()
       assert True, "Test Passed"



