from behave import *
from selenium import webdriver

@when(u'navigate to search page')
def step_impl(context):
    assert True,"Test passed"


@then('search page should disply')
def step_impl(context):
    assert True,"Test passed"


@when('navigate to advaced search page')
def step_impl(context):
    assert True, "Test passed"


@then('advanced search page should display')
def step_impl(context):
    assert True, "Test passed"
